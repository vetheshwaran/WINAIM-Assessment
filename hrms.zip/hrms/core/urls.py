from django.urls import include, path
from rest_framework.routers import DefaultRouter
from .views import EmployeeViewSet, DepartmentViewSet, RoleViewSet, PerformanceReviewViewSet

router = DefaultRouter()
router.register(r'employees', EmployeeViewSet)
router.register(r'departments', DepartmentViewSet)
router.register(r'roles', RoleViewSet)
router.register(r'performance_reviews', PerformanceReviewViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
]
