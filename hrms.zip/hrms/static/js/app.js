$(document).ready(function() {
    function loadEmployees() {
        $.get('/api/employees/', function(data) {
            let content = '<ul>';
            data.forEach(employee => {
                content += `<li>${employee.first_name} ${employee.last_name}</li>`;
            });
            content += '</ul>';
            $('#employee-list').html(content);
        });
    }

    loadEmployees();

    $('#employeeForm').submit(function(e) {
        e.preventDefault();
        const employee = {
            first_name: $('#firstName').val(),
            last_name: $('#lastName').val(),
            email: $('#email').val(),
            phone: $('#phone').val(),
            hire_date: $('#hireDate').val(),
            department_id: $('#departmentId').val(),
            role_id: $('#roleId').val()
        };
        $.ajax({
            type: "POST",
            url: "/api/employees/",
            data: JSON.stringify(employee),
            contentType: "application/json",
            success: function() {
                loadEmployees();
            }
        });
    });
});
